package com.inautix.seminar;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.inautix.DButil.DBUtil;

public class Validate {
	public String validateUser(LoginBean bean) throws SQLException {
		DBUtil connect = new DBUtil();
		Connection con = null;
		String preference = null;
		String password = null;
		try {
			con = connect.getDBConnection();
			if (con != null) {
				String query = "select * from t_xbbnhgy_logindetails where userid = ?";
				PreparedStatement stmt = con.prepareStatement(query);
				stmt.setString(1, bean.getUserName());
				ResultSet rs = stmt.executeQuery();
				if (rs != null) {
					while (rs.next()) {
						password = rs.getString(2);
						if (password.equals(bean.getPassword())) {
							preference = rs.getString(3);
						}
					}
				}
			}
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		}
		return preference;
	}
}
