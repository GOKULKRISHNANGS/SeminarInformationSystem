package com.inautix.administration;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import com.inautix.DButil.DBUtil;
import com.inautix.student.StudentBean;

public class AdministratorDAO {
	public void viewCourse() {

	}

	public void viewToics() {

	}

	public void viewClassRooms() {

	}

	public void viewCalender() {

	}

	public void manageProfessors() {

	}

	public int deleteAccount(StudentBean studentbean) throws SQLException {
		DBUtil connect = new DBUtil();
		Connection con = null;
		AdministratorBean adminbean = new AdministratorBean();
		int result = 0;
		try {
			con = connect.getDBConnection();
			if (con != null) {
				String query = "delete from t_xbbnhgy_logindetails where userid = ?";
				PreparedStatement stmt = con.prepareStatement(query);
				stmt.setString(1, adminbean.getUserID());
				result = stmt.executeUpdate();
			}

		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		} finally {
			con.close();
		}
		return result;
	}

	public int createAccount(StudentBean studentbean) throws SQLException {
		DBUtil connect = new DBUtil();
		Connection con = null;
		AdministratorBean adminbean = new AdministratorBean();
		int result = 0;
		try {
			con = connect.getDBConnection();
			if (con != null) {
				String query = "insert into t_xbbnhgy_logindetails values(?,?,?)";
				PreparedStatement stmt = con.prepareStatement(query);
				stmt.setString(1, adminbean.getUserID());
				stmt.setString(2, adminbean.getPassword());
				stmt.setString(3, adminbean.getPreference());
				result = stmt.executeUpdate();
			}

		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		} finally {
			con.close();
		}
		return result;
	}
}
