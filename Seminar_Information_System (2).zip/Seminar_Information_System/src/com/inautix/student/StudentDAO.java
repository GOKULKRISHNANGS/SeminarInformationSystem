package com.inautix.student;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.inautix.DButil.DBUtil;
import com.inautix.courses.CoursesBean;

public class StudentDAO {
	
	public void applyCourse(String userID) throws SQLException {
		DBUtil connect = new DBUtil();
		Connection con = null;
		String studentID = null;
		try {
			con = connect.getDBConnection();
			if (con != null) {
				String query = "select studentid from t_xbbnhgy_student where userid = ? ";
				PreparedStatement stmt = con.prepareStatement(query);
				stmt.setString(1, userID);
				ResultSet rs = stmt.executeQuery();
				while(rs.next()){
					studentID = rs.getString(1);
				}
				stmt.close();
				query = "";
						
			}

		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		} finally {
			con.close();
		}
	}
	
	public void viewCourseCalender() {
		
	}

	public ArrayList<CoursesBean> viewMyCourses(String userID) throws SQLException {
		DBUtil connect = new DBUtil();
		ArrayList<CoursesBean> arraylist = new ArrayList<CoursesBean>();
		Connection con = null;
		String studentID = null;
		try {
			con = connect.getDBConnection();
			if (con != null) {
				String query = "select studentid from t_xbbnhgy_student where userid = ? ";
				PreparedStatement stmt = con.prepareStatement(query);
				stmt.setString(1, userID);
				ResultSet rs = stmt.executeQuery();
				while(rs.next()){
					studentID = rs.getString(1);
				}
				stmt.close();
				query = "select * from t_xbbnhgy_courses natural join t_xbbnhgy_registry where studentid = ? ";
				stmt = con.prepareStatement(query);
				stmt.setString(1, studentID);
				rs = stmt.executeQuery();
				while(rs.next()){
					CoursesBean bean = new CoursesBean();
					bean.setCourseID(rs.getInt(1));
					bean.setCourseName(rs.getString(2));
					bean.setProfessorID(rs.getString(3));
					arraylist.add(bean);
				}
			}

		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		} finally {
			con.close();
		}
		return arraylist;
	}

	public void viewProfessors() {

	}
}
