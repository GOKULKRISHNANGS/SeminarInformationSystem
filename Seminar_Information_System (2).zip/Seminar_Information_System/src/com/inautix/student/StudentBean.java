package com.inautix.student;

public class StudentBean {
	private String studentID;
	private String studentName;
	private String stream;
	public String getStudentID() {
		return studentID;
	}
	public StudentBean(String studentID, String studentName, String stream,
			String studentMailID) {
		this.studentID = studentID;
		this.studentName = studentName;
		this.stream = stream;
		this.studentMailID = studentMailID;
	}
	public void setStudentID(String studentID) {
		this.studentID = studentID;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public String getStream() {
		return stream;
	}
	public void setStream(String stream) {
		this.stream = stream;
	}
	public String getStudentMailID() {
		return studentMailID;
	}
	public void setStudentMailID(String studentMailID) {
		this.studentMailID = studentMailID;
	}
	private String studentMailID;
}
