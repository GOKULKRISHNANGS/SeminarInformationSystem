package com.inautix.courses;

import java.util.Date;
import java.util.List;

public class CourseFunctions {

	public List<CoursesBean> decideUpdates(List<CoursesBean> list) {
		for (CoursesBean bean : list) {
			Date startdate = bean.getFromTime();
			Date enddate = bean.getToTime();
			Date currentdate = new Date();
			int started = (int) ((startdate.getTime() - currentdate.getTime()) / (1000 * 60 * 60 * 24));
			int ended = (int) ((currentdate.getTime() - enddate.getTime()) / (1000 * 60 * 60 * 24));
			if (started < 5 && started >= 0) {
				bean.setTimeCreated("Recent");
			} else if (ended > 0) {
				bean.setTimeCreated("Expired");
			} else if (ended < 0) {
				bean.setTimeCreated("Started");
			}
		}
		return list;
	}

}
