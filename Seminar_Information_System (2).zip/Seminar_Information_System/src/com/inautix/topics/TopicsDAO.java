package com.inautix.topics;

public interface TopicsDAO {
	public void viewTopics();
	public void viewTopicInformation();
	public void createTopic();
	public void modifyTopic();
	public void removeTopic();
}
