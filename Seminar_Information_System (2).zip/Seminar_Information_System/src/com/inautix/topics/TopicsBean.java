package com.inautix.topics;

public class TopicsBean {
	public String topicName;
	public int noOfPeriods;

	public String getTopicName() {
		return topicName;
	}

	public void setTopicName(String topicName) {
		this.topicName = topicName;
	}

	public int getNoOfPeriods() {
		return noOfPeriods;
	}

	public void setNoOfPeriods(int noOfPeriods) {
		this.noOfPeriods = noOfPeriods;
	}
}
