package com.inautix.servletcontainer;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.inautix.courses.CoursesBean;
import com.inautix.professor.ProfessorDAO;
import com.inautix.student.StudentDAO;

public class ViewMyCourses extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public ViewMyCourses() {
		super();
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(false);
		if (session == null) {
			RequestDispatcher rd = request
					.getRequestDispatcher("LoginPage.html");
			rd.forward(request, response);
		} else {
			String userID = String.valueOf(session.getAttribute("name"));
			String preference = String.valueOf(session
					.getAttribute("preference"));
			List<CoursesBean> arraylist = new ArrayList<CoursesBean>();
			StudentDAO studentdao = new StudentDAO();
			ProfessorDAO professordao = new ProfessorDAO();
			try {
				if (preference.equals("student")) {
					arraylist = studentdao.viewMyCourses(userID);
					request.setAttribute("arraylist", arraylist);
					RequestDispatcher rd = request
							.getRequestDispatcher("studentmycourses.jsp");
					rd.forward(request, response);
				} else if (preference.equals("professor")) {
					arraylist = professordao.viewMyCourses(userID);
					request.setAttribute("arraylist", arraylist);
					RequestDispatcher rd = request
							.getRequestDispatcher("professormycourses.jsp");
					rd.forward(request, response);
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
	}

}
