package com.inautix.servletcontainer;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.inautix.coursecalender.CourseCalenderBean;
import com.inautix.coursecalender.CourseCalenderDAO;
import com.inautix.courses.CoursesBean;
import com.inautix.courses.CoursesDAO;
import com.inautix.professor.ProfessorDAO;

public class CreateCourse extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public CreateCourse() {
		super();
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		HttpSession session = request.getSession(false);
		CoursesBean coursesbean = new CoursesBean();
		CourseCalenderBean calenderbean = new CourseCalenderBean();
		ProfessorDAO professordao = new ProfessorDAO();
		CourseCalenderDAO calenderdao = new CourseCalenderDAO();
		CoursesDAO coursesdao = new CoursesDAO();
		String courseName = "";
		int courseID = 0;
		String professorID = "";
		Date fromTime = null;
		Date toTime = null;
		try {
			courseName = request.getParameter("coursename");
			courseID = Integer.valueOf(request.getParameter("courseid"));
			professorID = professordao.getProfessorID((String)session.getAttribute("name"));
			fromTime = calenderbean
					.formatDate(request.getParameter("fromtime"));
			toTime = calenderbean.formatDate(request.getParameter("totime"));
			System.out.println(request.getParameter("totime")+"--------------------------");
			coursesbean.setCourseName(courseName);
			coursesbean.setCourseID(courseID);
			coursesbean.setProfessorID(professorID);
			calenderbean.setCourseID(courseID);
			calenderbean.setFromTime(fromTime);
			calenderbean.setToTime(toTime);
			String comments = request.getParameter("preface");
			coursesdao.modifyCourse(comments, courseName);

			int result = 0;

			try {
				result = coursesdao.createCourse(coursesbean);
			} catch (SQLException e) {
				e.printStackTrace();
			}

			try {
				result = calenderdao.addCourseDetails(calenderbean);
			} catch (SQLException e) {
				e.printStackTrace();
			}

			if (result > 0) {
				response.sendRedirect("ViewMyCourses");
				out.print("Successfully created new course");
			} else {
				RequestDispatcher rd = getServletContext()
						.getRequestDispatcher("/professormycourses.jsp");
				out.print("Invalid input");
				rd.include(request, response);
			}
		} catch (Exception e) {
			RequestDispatcher rd = getServletContext().getRequestDispatcher(
					"/professorcreatenewcourse.jsp");
			out.print("<script>");
			out.print("alert('Invalid Input');");
			out.print("</script>");
			rd.include(request, response);
		}

	}

}
