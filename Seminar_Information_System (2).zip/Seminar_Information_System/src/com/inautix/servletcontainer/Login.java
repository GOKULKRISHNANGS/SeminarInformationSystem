package com.inautix.servletcontainer;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.inautix.seminar.LoginBean;
import com.inautix.seminar.Validate;

public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public Login() {
		super();
	}

	/*
	 * protected void doGet(HttpServletRequest request, HttpServletResponse
	 * response) throws ServletException, IOException {
	 * 
	 * }
	 */

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String userID = request.getParameter("uname");
		String password = request.getParameter("psw");

		LoginBean bean = new LoginBean();
		bean.setUserName(userID);
		bean.setPassword(password);

		Validate valid = new Validate();
		String preference = null;
		try {
			preference = valid.validateUser(bean);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		if (preference != null) {
			HttpSession session = request.getSession();
			session.setAttribute("name", userID);
			session.setAttribute("preference", preference);
			if (preference.equals("student")) {
				RequestDispatcher rd = request
						.getRequestDispatcher("studentdashboard.jsp");
				rd.forward(request, response);
			} else if (preference.equals("professor")) {
				RequestDispatcher rd = request
						.getRequestDispatcher("professordashboard.jsp");
				rd.forward(request, response);
			} else if (preference.equals("admin")) {
				RequestDispatcher rd = request
						.getRequestDispatcher("admindashboard.jsp");
				rd.forward(request, response);
			}
		} else {
			RequestDispatcher rd = getServletContext().getRequestDispatcher(
					"/LoginPage.html");
			out.println("<font color=red><centere>Either user name or password is wrong.</center></font>");
			rd.include(request, response);
		}
	}
}
