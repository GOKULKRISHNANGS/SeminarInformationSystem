package com.inautix.coursetopic;

import java.util.List;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Component;

import com.inautix.rowmapper.TestRowMapper;

@Component
public class TopicsDAOAutowired extends JdbcDaoSupport {

	final static Logger logger = Logger.getLogger(TopicsDAOAutowired.class);

	@Autowired
	public TopicsDAOAutowired(DataSource datasource) {
		// TODO Auto-generated constructor stub
		setDataSource(datasource);
	}

	public List<TopicBean> getTopics(TopicBean topicbean) {
		List<TopicBean> topicList = null;
		topicList = getJdbcTemplate().query(
				"select * from t_xbbnhgy_topics where topicname = '"
						+ topicbean.getTopicName() + "'", new TestRowMapper());
		
		logger.info("Inside "+getClass());
		
		return topicList;
	}
}
