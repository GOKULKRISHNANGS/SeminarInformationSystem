package com.inautix.coursetopic;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel
public class TopicBean {
	@ApiModelProperty(position = 1, required = true, value = "tpicname")
	private String topicName;
	@ApiModelProperty(position = 2, required = true, value = "courseId")
	private int courseId;
	@ApiModelProperty(position = 3, required = true, value = "contents")
	private String contents;

	public String getTopicName() {
		return topicName;
	}

	public void setTopicName(String topicName) {
		this.topicName = topicName;
	}

	public int getCourseId() {
		return courseId;
	}

	public void setCourseId(int courseId) {
		this.courseId = courseId;
	}

	public String getContents() {
		return contents;
	}

	public void setContents(String contents) {
		this.contents = contents;
	}
}
