package com.inautix.coursetopic;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.inautix.DButil.DBUtil;

public class TopicsDAO {

	final static Logger logger = Logger.getLogger(TopicsDAO.class);

	public int insertTopics(TopicBean topicBean) throws SQLException {
		DBUtil connect = new DBUtil();
		Connection con = null;
		int r = 0;
		try {
			con = connect.getDBConnection();
			String query = "insert into t_xbbnhgy_topics values(?,?,?)";
			PreparedStatement stmt = con.prepareStatement(query);
			stmt = con.prepareStatement(query);
			stmt.setString(1, topicBean.getTopicName());
			stmt.setInt(2, topicBean.getCourseId());
			stmt.setString(3, topicBean.getContents());
			r = stmt.executeUpdate();
		} catch (Exception e1) {
			e1.printStackTrace();
		} finally {
			con.close();
		}
		return r;
	}

	public List<TopicBean> getTopics(TopicBean topicbean) throws SQLException {
		DBUtil connect = new DBUtil();
		Connection con = null;
		ResultSet resultset = null;
		List<TopicBean> list = new ArrayList<TopicBean>();
		try {
			con = connect.getDBConnection();
			String query = "select topicname from t_xbbnhgy_topics where courseid = ?";
			PreparedStatement stmt = con.prepareStatement(query);
			System.out.println("Course ID is " + topicbean.getCourseId());

			stmt = con.prepareStatement(query);
			stmt.setInt(1, topicbean.getCourseId());
			resultset = stmt.executeQuery();
			while (resultset.next()) {
				TopicBean bean = new TopicBean();
				bean.setTopicName(resultset.getString(1));
				list.add(bean);
			}
		} catch (Exception e1) {
			/* e1.printStackTrace(); */
			logger.info(e1);
		} finally {
			con.close();
		}

		return list;
	}

	public List<TopicBean> getTopicContent(TopicBean topicbean)
			throws SQLException {
		DBUtil connect = new DBUtil();
		Connection con = null;
		ResultSet resultset = null;
		List<TopicBean> list = new ArrayList<TopicBean>();
		try {
			con = connect.getDBConnection();
			String query = "select content from t_xbbnhgy_topics where topicname = ?";
			PreparedStatement stmt = con.prepareStatement(query);
			System.out.println("Course ID is " + topicbean.getTopicName());
			stmt = con.prepareStatement(query);
			stmt.setString(1, topicbean.getTopicName());
			resultset = stmt.executeQuery();
			while (resultset.next()) {
				TopicBean bean = new TopicBean();
				bean.setContents(resultset.getString(1));
				bean.setTopicName(topicbean.getTopicName());
				System.out.println(resultset.getString(1));
				list.add(bean);
			}
		} catch (Exception e1) {
			e1.printStackTrace();
		} finally {
			con.close();
		}

		return list;
	}

}
