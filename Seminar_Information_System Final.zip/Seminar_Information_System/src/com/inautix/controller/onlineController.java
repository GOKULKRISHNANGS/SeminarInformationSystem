package com.inautix.controller;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.inautix.coursetopic.TopicBean;
import com.inautix.coursetopic.TopicsDAO;
import com.inautix.coursetopic.TopicsDAOAutowired;

@RestController
@RequestMapping(value = "/stocks")
public class onlineController {
	
	@Autowired
	TopicsDAOAutowired topicdao;

	onlineController() {
		System.out.println("Inside Controller");
	}

	@RequestMapping(value = "/getall", method = RequestMethod.POST, produces = { MediaType.APPLICATION_JSON_VALUE })
	public List<TopicBean> getAllTestDetails(@RequestBody TopicBean topicBean) {
		System.out.println("Inside Controllers");
		List<TopicBean> testList;
		testList = topicdao.getTopics(topicBean);
		return testList;
	}

	@RequestMapping(value = "/all", method = RequestMethod.PUT)
	public List<TopicBean> getAllStocks(@RequestBody TopicBean topicbean)
			throws SQLException {
		System.out.println("Inside Stock Controller ****************");
		TopicsDAO topicdao = new TopicsDAO();
		List<TopicBean> list = new ArrayList<>();
		list = topicdao.getTopics(topicbean);
		return list;
	}

/*	@RequestMapping(value = "/contents", method = RequestMethod.PUT)
	public List<TopicBean> getContent(@RequestBody TopicBean topicbean)
			throws SQLException {
		System.out
				.println("****************** Inside Stock Controller ****************");
		TopicsDAO topicdao = new TopicsDAO();
		List<TopicBean> list = new ArrayList<>();
		list = topicdao.getTopicContent(topicbean);
		return list;
	}*/

}