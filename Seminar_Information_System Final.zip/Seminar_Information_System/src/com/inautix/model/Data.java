package com.inautix.model;

import io.swagger.annotations.ApiModelProperty;

import java.util.List;

import com.inautix.coursetopic.TopicBean;

public class Data {

	@ApiModelProperty(position = 1, required = true, value = "brief description of the property :output ")
	private List<TopicBean> output;

	public List<TopicBean> getOutput() {
		return output;
	}

	public void setOutput(List<TopicBean> outputList) {
		this.output = outputList;
	}

}
