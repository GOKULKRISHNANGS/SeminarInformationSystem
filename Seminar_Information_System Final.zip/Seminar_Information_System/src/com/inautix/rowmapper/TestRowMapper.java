package com.inautix.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.inautix.coursetopic.TopicBean;

public class TestRowMapper implements RowMapper<TopicBean> {
	
	public TopicBean mapRow(ResultSet rs, int rownum) throws SQLException {
		// TODO Auto-generated method stub

		TopicBean testObj = new TopicBean();
		testObj.setTopicName(rs.getString(1));
		testObj.setCourseId(rs.getInt(2));
		testObj.setContents(rs.getString(3));
		return testObj;
	}

}
