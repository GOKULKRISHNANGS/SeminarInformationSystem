function readFile(id) {
	/* alert(id); */
	var file = document.getElementById(id).files[0];
	/* alert(file); */
	var reader = new FileReader();
	reader.addEventListener("load", function() {
		document.getElementById("file" + id).name = "fcontent" + id;
		document.getElementById("file" + id).value = reader.result;
		/* alert(reader.result); */
	}, false);
	if (file) {
		reader.readAsText(file, 'UTF-8');
	}
}
$(document)
		.ready(
				function() {
					var counter = 1;
					$("#addrow")
							.on(
									"click",
									function() {
										var newRow = $("<tr>");
										var cols = "";
										cols += '<td><input type="text" class="form-control" name="name'
												+ counter
												+ '" required/></td> ';
										cols += '<td><label for="ms">File</label><input type = "file" onchange="readFile(this.id)" id='
												+ counter
												+ ' name = "File'
												+ counter + '" ></td>';
										cols += '<td><input type="button" class="ibtnDel btn btn-md btn-danger "  value="Delete"><input type=hidden id=file'
												+ counter + '></td>';
										newRow.append(cols);
										$("table.order-list").append(newRow);
										counter++;
										document.newcourse.count.value = ""
												+ counter;
									});

					$("table.order-list").on("click", ".ibtnDel",
							function(event) {
								$(this).closest("tr").remove();
							});
				});
