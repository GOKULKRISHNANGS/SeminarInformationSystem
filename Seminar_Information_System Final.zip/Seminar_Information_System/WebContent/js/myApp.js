var app = angular.module("myApp", []);
app.controller("maincontroller", function($scope, $http) {
	$scope.courseId = null;
	$scope.topicName = null;
	$scope.contents = null;

	$scope.putdata = function(courseId) {
		var data = {
			topicName : 'a',
			courseId : courseId,
			contents : 'a'
		};
		/* window.alert(JSON.stringify(data)); */

		// Call the services
		$http.put('stocks/all', data).success(
				function(data, status, headers, config) {
					$scope.Details = data;
				}).error(
				function(data, status, header, config) {
					$scope.ResponseDetails = "Data: " + data + "<hr />status: "
							+ status + "<hr />headers: " + header
							+ "<hr />config: " + config;
				});
	};

	$scope.getcontent = function(topicName, id) {
		/* alert(topicName); */

		var data = {
			topicName : topicName,
			courseId : id,
			contents : 'a'
		};
		/* window.alert(JSON.stringify(data)); */

		// Call the services
		$http.post('stocks/getall', data).success(
				function(data, status, headers, config) {
					$scope.content = data;
					/*alert($scope.content);*/
				}).error(
				function(data, status, header, config) {
					$scope.ResponseDetails = "Data: " + data + "<hr />status: "
							+ status + "<hr />headers: " + header
							+ "<hr />config: " + config;
				});
	};
});