function enroll(){
	window.alert("You have successfully enrolled for this course!");
}
function conversion(){
    var file    = document.querySelector('input[type=file]').files[0];

    var reader  = new FileReader();
    reader.addEventListener("load", function () {
          /*alert(reader.result);*/
          document.getElementById("profile").value=reader.result;
          }, false);
          if (file) {
            reader.readAsDataURL(file);
          }
}
