create table t_xbbnhgy_logindetails(userid varchar(30) primary key, password varchar(20), preference varchar(10));
insert into t_xbbnhgy_logindetails values('admin@gmail.com', 'admin','admin');
create table t_xbbnhgy_student(studentid varchar(6) primary key, studentname varchar(30), stream varchar(10), userid varchar(30) references t_xbbnhgy_logindetails(userid));
create table t_xbbnhgy_professor(professorid varchar(6) primary key, professorname varchar(30), experience int,userid varchar(30) references t_xbbnhgy_logindetails(userid));
create table t_xbbnhgy_courses(courseid int primary key,coursename varchar(15),professorid varchar(6) references t_xbbnhgy_professor(professorid),image clob);
create table t_xbbnhgy_coursecalender(courseid int primary key, timefrom date, totime date);
create table t_xbbnhgy_topics(topicname varchar(20), courseid int references t_xbbnhgy_courses(courseid), content clob, primary key(topicname));
create table t_xbbnhgy_administrator(name varchar(20), userid varchar(30) references t_xbbnhgy_logindetails(userid));
create table t_xbbnhgy_registry (studentid varchar(6) references t_xbbnhgy_student(studentid), courseid int references t_xbbnhgy_courses(courseid));
set schema courses;
delete from t_xbbnhgy_topics;

select * from t_xbbnhgy_coursecalender;

delete from t_xbbnhgy_courses where courseid = 544;

DELETE from t_xbbnhgy_coursecalender where courseid = 544;

delete from t_xbbnhgy_slogindetails where userid =  '"krish@gmail.com"';

delete from t_xbbnhgy_registry where courseid = 544;

delete from t_xbbnhgy_topics where courseid = 544;

truncate table t_xbbnhgy_courses;

drop table t_xbbnhgy_courses;
drop table t_xbbnhgy_topics;
drop table t_xbbnhgy_registry;
drop table t_xbbnhgy_coursecalender;
select * from t_xbbnhgy_topics;
select * from t_xbbnhgy_courses;
desc table t_xbbnhgy_courses;
